/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';

// Global singleton to prevent re-opening on dev server reloads
declare global {
  var _pgliteInstance: PGlite | undefined;
}

export function getDatabasePath(): string {
  const customPath = process.env.DATABASE_PATH || './data/postgres';
  const resolved = path.resolve(process.cwd(), customPath);
  if (!fs.existsSync(resolved)) {
    fs.mkdirSync(resolved, { recursive: true });
  }
  return resolved;
}

export async function getDb(): Promise<PGlite> {
  if (global._pgliteInstance) {
    return global._pgliteInstance;
  }

  const dbPath = getDatabasePath();

  try {
    const pidFile = path.join(dbPath, 'postmaster.pid');
    if (fs.existsSync(pidFile)) {
      try {
        fs.unlinkSync(pidFile);
      } catch {
        // ignore
      }
    }
    const instance = new PGlite(dbPath);
    await instance.waitReady;
    global._pgliteInstance = instance;
    return instance;
  } catch (err: any) {
    console.error('Failed to initialize database at', dbPath, ':', err?.message || err);
    console.warn('Re-initializing clean database directory to recover from abort/corruption...');
    try {
      if (fs.existsSync(dbPath)) {
        const backupPath = `${dbPath}.corrupted.${Date.now()}`;
        try {
          fs.renameSync(dbPath, backupPath);
        } catch {
          fs.rmSync(dbPath, { recursive: true, force: true });
        }
        fs.mkdirSync(dbPath, { recursive: true });
      }
      const recoveredInstance = new PGlite(dbPath);
      await recoveredInstance.waitReady;
      global._pgliteInstance = recoveredInstance;
      // Re-run migrations on fresh directory
      const { runMigrations } = await import('./schema.ts');
      await runMigrations();
      return recoveredInstance;
    } catch (fallbackErr: any) {
      console.error('Filesystem database failed, using in-memory database:', fallbackErr);
      const memInstance = new PGlite();
      await memInstance.waitReady;
      global._pgliteInstance = memInstance;
      const { runMigrations } = await import('./schema.ts');
      await runMigrations();
      return memInstance;
    }
  }
}

/**
 * Execute parameterized query with automatic parameter handling and abort recovery
 */
export async function query<T = any>(sql: string, params: any[] = []): Promise<{ rows: T[]; rowCount: number }> {
  try {
    const db = await getDb();
    const res = await db.query<T>(sql, params);
    return {
      rows: res.rows,
      rowCount: res.rows.length
    };
  } catch (error: any) {
    const msg = error?.message || String(error);
    console.error('PostgreSQL query error:', msg, '\nQuery:', sql, '\nParams:', params);
    // If instance aborted, clear it so next call recovers
    if (msg.includes('Aborted') || msg.includes('closed') || msg.includes('dead')) {
      console.warn('PostgreSQL engine aborted; clearing global instance to trigger reconnection.');
      global._pgliteInstance = undefined;
    }
    throw error;
  }
}

export interface TxDb {
  query: <T = any>(sql: string, params?: any[]) => Promise<{ rows: T[] }>;
  exec: (sql: string) => Promise<any>;
}

/**
 * Transaction helper executing callback in BEGIN ... COMMIT / ROLLBACK
 */
export async function transaction<T>(callback: (db: TxDb) => Promise<T>): Promise<T> {
  const db = await getDb();
  await db.query('BEGIN');
  try {
    const result = await callback(db as any);
    await db.query('COMMIT');
    return result;
  } catch (error: any) {
    try {
      await db.query('ROLLBACK');
    } catch {
      // rollback might fail if db aborted
    }
    const msg = error?.message || String(error);
    if (msg.includes('Aborted') || msg.includes('closed') || msg.includes('dead')) {
      global._pgliteInstance = undefined;
    }
    throw error;
  }
}

// Clean up database instance on server shutdown
const gracefulShutdown = async () => {
  if (global._pgliteInstance) {
    try {
      await global._pgliteInstance.close();
      global._pgliteInstance = undefined;
    } catch {
      // ignore
    }
  }
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
