/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query } from '../db/connection.ts';
import { requireAuth, requireRoles, AuthRequest } from '../middleware/auth.ts';
import { logAudit } from '../services/audit.ts';

export const usersRouter = Router();

// List Users (Super Administrator Only)
usersRouter.get('/', requireAuth, requireRoles('super_admin'), async (req: AuthRequest, res) => {
  try {
    const result = await query(
      `SELECT id, email, full_name, phone_number, national_id, role, is_active, created_at, updated_at
       FROM users
       ORDER BY created_at DESC`
    );
    return res.json(result.rows);
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to fetch users' });
  }
});

// Create User (Super Administrator Only - prevents public privilege escalation)
const createUserSchema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
  phoneNumber: z.string().min(9),
  nationalId: z.string().optional(),
  role: z.enum(['super_admin', 'caretaker', 'tenant'])
});

usersRouter.post('/', requireAuth, requireRoles('super_admin'), async (req: AuthRequest, res) => {
  try {
    const parse = createUserSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: 'Validation failed', details: parse.error.issues });
    }

    const { fullName, email, password, phoneNumber, nationalId, role } = parse.data;

    const existingCheck = await query(`SELECT id FROM users WHERE LOWER(email) = LOWER($1)`, [email]);
    if (existingCheck.rows.length > 0) {
      return res.status(400).json({ error: 'A user with this email address already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const insertRes = await query(
      `INSERT INTO users (full_name, email, password_hash, phone_number, national_id, role)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, email, full_name, phone_number, national_id, role, is_active, created_at`,
      [fullName, email.toLowerCase(), passwordHash, phoneNumber, nationalId || '', role]
    );

    const user = insertRes.rows[0];

    await logAudit({
      userId: req.user!.id,
      action: 'ADMIN_CREATED_USER',
      entityType: 'users',
      entityId: user.id,
      changes: { email: user.email, role: user.role, fullName: user.full_name },
      ipAddress: req.ip
    });

    return res.status(201).json(user);
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to create user' });
  }
});

// Toggle User Active Status
usersRouter.patch('/:id/toggle-status', requireAuth, requireRoles('super_admin'), async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    if (id === req.user!.id) {
      return res.status(400).json({ error: 'You cannot deactivate your own administrative account.' });
    }

    const updateRes = await query(
      `UPDATE users
       SET is_active = NOT is_active, updated_at = NOW()
       WHERE id = $1
       RETURNING id, email, full_name, role, is_active`,
      [id]
    );

    if (updateRes.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = updateRes.rows[0];

    await logAudit({
      userId: req.user!.id,
      action: user.is_active ? 'USER_ACTIVATED' : 'USER_DEACTIVATED',
      entityType: 'users',
      entityId: id,
      changes: { isActive: user.is_active },
      ipAddress: req.ip
    });

    return res.json({ message: `User status changed to ${user.is_active ? 'active' : 'inactive'}`, user });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to toggle user status' });
  }
});

// Admin Password Reset for User
usersRouter.post('/:id/reset-password', requireAuth, requireRoles('super_admin'), async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    const updateRes = await query(
      `UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2 RETURNING email, full_name`,
      [passwordHash, id]
    );

    if (updateRes.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    await logAudit({
      userId: req.user!.id,
      action: 'ADMIN_RESET_PASSWORD',
      entityType: 'users',
      entityId: id,
      ipAddress: req.ip
    });

    return res.json({ message: `Password reset successfully for ${updateRes.rows[0].email}` });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to reset password' });
  }
});
