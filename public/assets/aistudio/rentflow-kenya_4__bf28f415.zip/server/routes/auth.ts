/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query } from '../db/connection.ts';
import { signToken, requireAuth, AuthRequest } from '../middleware/auth.ts';
import { logAudit } from '../services/audit.ts';

export const authRouter = Router();

// Check if system requires initial super administrator setup
authRouter.get('/setup-status', async (req, res) => {
  try {
    const result = await query('SELECT COUNT(*) as count FROM users');
    const userCount = parseInt(result.rows[0].count, 10);
    return res.json({
      needsInitialSetup: userCount === 0,
      userCount
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to check setup status' });
  }
});

// Setup First Super Administrator
const setupFirstAdminSchema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
  phoneNumber: z.string().min(9),
  nationalId: z.string().optional()
});

authRouter.post('/setup-first-admin', async (req, res) => {
  try {
    const checkUsers = await query('SELECT COUNT(*) as count FROM users');
    const count = parseInt(checkUsers.rows[0].count, 10);
    if (count > 0) {
      return res.status(403).json({ 
        error: 'Initial setup is already completed. Super Administrator exists.' 
      });
    }

    const parse = setupFirstAdminSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: 'Validation failed', details: parse.error.issues });
    }

    const { fullName, email, password, phoneNumber, nationalId } = parse.data;
    const passwordHash = await bcrypt.hash(password, 10);

    const insertRes = await query(
      `INSERT INTO users (full_name, email, password_hash, phone_number, national_id, role)
       VALUES ($1, $2, $3, $4, $5, 'super_admin')
       RETURNING id, full_name, email, role, created_at`,
      [fullName, email.toLowerCase(), passwordHash, phoneNumber, nationalId || '']
    );

    const user = insertRes.rows[0];

    await logAudit({
      userId: user.id,
      action: 'SYSTEM_INITIAL_ADMIN_CREATED',
      entityType: 'users',
      entityId: user.id,
      changes: { email: user.email, role: 'super_admin' },
      ipAddress: req.ip
    });

    const token = signToken({
      id: user.id,
      email: user.email,
      role: 'super_admin',
      fullName: user.full_name
    });

    return res.status(201).json({
      message: 'Super Administrator setup completed successfully.',
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role
      }
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Setup failed' });
  }
});

// Login
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

authRouter.post('/login', async (req, res) => {
  try {
    const parse = loginSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: 'Please enter a valid email and password' });
    }

    const { email, password } = parse.data;
    const userRes = await query(
      `SELECT id, email, password_hash, full_name, role, is_active FROM users WHERE LOWER(email) = LOWER($1)`,
      [email]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = userRes.rows[0];
    if (!user.is_active) {
      return res.status(403).json({ error: 'This account has been deactivated. Please contact management.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Retrieve tenant ID if user is tenant
    let tenantId = null;
    if (user.role === 'tenant') {
      const tenantRes = await query(`SELECT id FROM tenants WHERE user_id = $1`, [user.id]);
      if (tenantRes.rows.length > 0) {
        tenantId = tenantRes.rows[0].id;
      }
    }

    const token = signToken({
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: user.full_name,
      tenantId
    });

    await logAudit({
      userId: user.id,
      action: 'USER_LOGIN',
      entityType: 'users',
      entityId: user.id,
      ipAddress: req.ip
    });

    return res.json({
      message: 'Signed in successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role,
        tenantId
      }
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Authentication error' });
  }
});

// Logout
authRouter.post('/logout', requireAuth, async (req: AuthRequest, res) => {
  if (req.user) {
    await logAudit({
      userId: req.user.id,
      action: 'USER_LOGOUT',
      entityType: 'users',
      entityId: req.user.id,
      ipAddress: req.ip
    });
  }
  return res.json({ message: 'Signed out successfully' });
});

// Current User Details
authRouter.get('/me', requireAuth, async (req: AuthRequest, res) => {
  try {
    const user = req.user!;
    const userRes = await query(
      `SELECT id, email, full_name, phone_number, national_id, role, created_at FROM users WHERE id = $1`,
      [user.id]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const dbUser = userRes.rows[0];
    let tenantInfo = null;

    if (dbUser.role === 'tenant') {
      const tenantRes = await query(
        `SELECT t.id, t.full_name, t.phone_number, t.national_id, t.emergency_contact_name, t.emergency_contact_phone,
                u.unit_number, p.name as property_name, p.address as property_address,
                ty.rent_amount_cents, ty.rent_due_day, ty.start_date, ty.id as tenancy_id
         FROM tenants t
         LEFT JOIN tenancies ty ON ty.tenant_id = t.id AND ty.is_active = TRUE
         LEFT JOIN rental_units u ON u.id = ty.unit_id
         LEFT JOIN properties p ON p.id = u.property_id
         WHERE t.user_id = $1`,
        [dbUser.id]
      );
      if (tenantRes.rows.length > 0) {
        tenantInfo = tenantRes.rows[0];
      }
    }

    return res.json({
      user: {
        id: dbUser.id,
        email: dbUser.email,
        fullName: dbUser.full_name,
        phoneNumber: dbUser.phone_number,
        nationalId: dbUser.national_id,
        role: dbUser.role,
        createdAt: dbUser.created_at,
        tenantId: user.tenantId,
        tenantInfo
      }
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to fetch user' });
  }
});

// Password Change
const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8)
});

authRouter.post('/change-password', requireAuth, async (req: AuthRequest, res) => {
  try {
    const parse = changePasswordSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: 'New password must be at least 8 characters' });
    }

    const { currentPassword, newPassword } = parse.data;
    const userRes = await query(`SELECT password_hash FROM users WHERE id = $1`, [req.user!.id]);
    
    const isMatch = await bcrypt.compare(currentPassword, userRes.rows[0].password_hash);
    if (!isMatch) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await query(`UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2`, [newHash, req.user!.id]);

    await logAudit({
      userId: req.user!.id,
      action: 'USER_PASSWORD_CHANGED',
      entityType: 'users',
      entityId: req.user!.id,
      ipAddress: req.ip
    });

    return res.json({ message: 'Password updated successfully' });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Failed to update password' });
  }
});
